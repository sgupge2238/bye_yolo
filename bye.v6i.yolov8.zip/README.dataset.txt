# bye > 2023-10-13 2:45pm
https://universe.roboflow.com/tomtom-0x2e8/bye-muawf

Provided by a Roboflow user
License: CC BY 4.0

